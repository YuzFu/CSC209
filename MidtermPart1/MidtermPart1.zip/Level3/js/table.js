// let ROW = `
// <tr>
// <td>Sample text</td>
// <td>CHECKCROSSBASIC</td>
// <td>CHECKCROSSPRO</td>
// </tr>
// `;

// window.alert(ROW);

let newROW = `<tr>
        <td>Sample text</td>
        <td><i class="fa fa-remove"></i></td>
        <td><i class="fa fa-check"></i></td>
      </tr>`

// window.alert(newROW);

document.getElementById('testRow').innerHTML = newROW;